WSO2 Integrator 5.0.0.1 — macOS repair kit
===========================================

Who this is for
---------------
Use this kit for either of these WSO2 Integrator 5.0.0.1 macOS defects:

1. An HTTP Service visualizer keeps loading forever.
2. An Intel Mac compiles a project but fails at runtime with:

   UnsatisfiedLinkError: Failed to load any of the given libraries:
   netty_tcnative_osx_x86_64

3. The default WSO2 model provider works initially but later fails with:

   Error while connecting to the model
   cause: Unauthorized

What to do
----------
1. Install WSO2 Integrator 5.0.0.1 in the Applications folder.
   - M1, M2, M3, M4, or later: download "macOS (Apple Silicon, DMG)".
   - Intel processor: download "macOS (x64, DMG)".
2. Start WSO2 Integrator once, and then quit it.
3. Double-click "WSO2-Integrator-macOS-Repair.command".
4. Wait for "Repair completed successfully".
5. Open the project and select its HTTP Service.

For the default WSO2 model provider, sign in to WSO2 Integrator Copilot once
and complete the GitHub device-code login if prompted. After that first login,
the repaired Run action refreshes WSO2's short-lived access token
automatically before starting projects that use the provider.

Intel Mac global runtime repair
-------------------------------
The main repair command also fixes the netty_tcnative_osx_x86_64 defect once
for the entire Intel Mac. Existing and future Ballerina projects then use the
repaired runtime automatically. There is no longer a separate per-project
repair step.

Apple Silicon installations contain the correct native library, so the global
runtime copy is not created there.

If macOS refuses to open the repair
-----------------------------------
Control-click the .command file, choose Open, and then choose Open again.

What the repair changes
-----------------------
- Installs the official WSO2 Ballerina extension version 5.12.3.
- Repairs three packaging/desktop compatibility defects in that extension.
- Adds the missing empty legacy theme file.
- Refreshes the default WSO2 model-provider token automatically before Run.
- Clears only disposable WSO2 Integrator webview caches.
- Disables automatic extension updates so the repair is not overwritten.
- Keeps a backup and automatically rolls back if validation fails.

It does not delete or modify integration projects.

What the Intel global TLS repair changes
----------------------------------------
- Creates a user-owned copy of WSO2's Ballerina 2201.13.4 distribution under
  ~/.ballerina/wso2-integrator-2201.13.4-fixed.
- Replaces the malformed HTTP and gRPC Intel native-library JARs in that copy
  with the verified official Netty 2.0.77.Final artifact.
- Configures WSO2 Integrator to use the repaired runtime globally.
- Reuses WSO2's bundled JDK through a symbolic link.
- Leaves the signed application bundle and all project source files untouched.

The bundled library has this Maven Central SHA-1 checksum:

3b3dfbf6136c0b278205f042f449ef8f20813ce6

Requirements
------------
- macOS on Intel or Apple Silicon
- WSO2 Integrator at /Applications/WSO2 Integrator.app
- Internet access for the visualizer repair (it downloads about 75 MB from
  Microsoft's official Visual Studio Marketplace)
