WSO2 Integrator 5.0.0.1 — macOS visual-editor repair
=======================================================

Who this is for
---------------
Use this when an HTTP Service keeps loading forever in WSO2 Integrator 5.0.0.1
on macOS.

What to do
----------
1. Install WSO2 Integrator 5.0.0.1 in the Applications folder.
   - M1, M2, M3, M4, or later: download "macOS (Apple Silicon, DMG)".
   - Intel processor: download "macOS (x64, DMG)".
2. Start WSO2 Integrator once, and then quit it.
3. Double-click "WSO2-Integrator-macOS-Repair.command".
4. Wait for "Repair completed successfully".
5. Open the project and select its HTTP Service.

If macOS refuses to open the repair
-----------------------------------
Control-click the .command file, choose Open, and then choose Open again.

What the repair changes
-----------------------
- Installs the official WSO2 Ballerina extension version 5.12.3.
- Repairs three packaging/desktop compatibility defects in that extension.
- Adds the missing empty legacy theme file.
- Clears only disposable WSO2 Integrator webview caches.
- Disables automatic extension updates so the repair is not overwritten.
- Keeps a backup and automatically rolls back if validation fails.

It does not delete or modify integration projects.

Requirements
------------
- macOS on Intel or Apple Silicon
- WSO2 Integrator at /Applications/WSO2 Integrator.app
- Internet access (the repair downloads about 75 MB from Microsoft's official
  Visual Studio Marketplace)
