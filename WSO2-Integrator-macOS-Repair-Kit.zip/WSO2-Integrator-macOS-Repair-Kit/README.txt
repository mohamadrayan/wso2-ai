WSO2 Integrator 5.0.0.1 — macOS repair kit
===========================================

Who this is for
---------------
Use this kit for either of these WSO2 Integrator 5.0.0.1 macOS defects:

1. An HTTP Service visualizer keeps loading forever.
2. An Intel Mac compiles a project but fails at runtime with:

   UnsatisfiedLinkError: Failed to load any of the given libraries:
   netty_tcnative_osx_x86_64

What to do
----------
1. Install WSO2 Integrator 5.0.0.1 in the Applications folder.
   - M1, M2, M3, M4, or later: download "macOS (Apple Silicon, DMG)".
   - Intel processor: download "macOS (x64, DMG)".
2. Start WSO2 Integrator once, and then quit it.
3. Double-click "WSO2-Integrator-macOS-Repair.command".
4. Wait for "Repair completed successfully".
5. Open the project and select its HTTP Service.

Intel Mac project repair
------------------------
Only use this section if a project reports the netty_tcnative_osx_x86_64
runtime error.

1. Double-click "WSO2-Ballerina-Project-TLS-Repair.command".
2. Select the specific project folder containing Ballerina.toml.
3. Wait while the tool adds the library and validates the project build.
4. Run the project again.

Run this tool once for each affected project. It does not change Ballerina
source code. Apple Silicon installations contain the correct library and the
tool will leave them unchanged.

If macOS refuses to open the repair
-----------------------------------
Control-click the .command file, choose Open, and then choose Open again.

What the repair changes
-----------------------
- Installs the official WSO2 Ballerina extension version 5.12.3.
- Repairs three packaging/desktop compatibility defects in that extension.
- Adds the missing empty legacy theme file.
- Clears only disposable WSO2 Integrator webview caches.
- Disables automatic extension updates so the repair is not overwritten.
- Keeps a backup and automatically rolls back if validation fails.

It does not delete or modify integration projects.

What the Intel project TLS repair changes
-----------------------------------------
- Copies the verified official Netty 2.0.77.Final macOS Intel native-library
  JAR into the selected project's libs folder.
- Adds that local JAR as a Java 21 platform dependency in Ballerina.toml.
- Saves Ballerina.toml.before-wso2-tls-repair before changing the manifest.
- Builds the project and confirms the native binary is present in the
  generated executable.

The bundled library has this Maven Central SHA-1 checksum:

3b3dfbf6136c0b278205f042f449ef8f20813ce6

Requirements
------------
- macOS on Intel or Apple Silicon
- WSO2 Integrator at /Applications/WSO2 Integrator.app
- Internet access for the visualizer repair (it downloads about 75 MB from
  Microsoft's official Visual Studio Marketplace)
