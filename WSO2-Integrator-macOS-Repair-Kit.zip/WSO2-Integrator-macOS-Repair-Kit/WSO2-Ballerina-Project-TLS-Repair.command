#!/bin/bash

set -euo pipefail

APP="/Applications/WSO2 Integrator.app"
BAL="$APP/Contents/components/ballerina/bin/bal"
JAR_NAME="netty-tcnative-boringssl-static-2.0.77.Final-osx-x86_64.jar"
EXPECTED_SHA1="3b3dfbf6136c0b278205f042f449ef8f20813ce6"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ASSET="$SCRIPT_DIR/assets/$JAR_NAME"
WORK_DIR="$(mktemp -d "${TMPDIR:-/tmp}/wso2-project-tls-repair.XXXXXX")"

cleanup() {
    if [ -d "$WORK_DIR" ]; then
        find "$WORK_DIR" -depth -delete 2>/dev/null || true
    fi
}
trap cleanup EXIT

show_message() {
    local message="$1"
    echo
    echo "$message"
    echo
    if [ "${WSO2_REPAIR_NO_DIALOGS:-0}" != "1" ]; then
        osascript -e "display dialog \"${message}\" buttons {\"OK\"} default button \"OK\" with icon note giving up after 30" 2>/dev/null || true
    fi
}

show_error() {
    local message="$1"
    echo
    echo "ERROR: $message"
    echo
    if [ "${WSO2_REPAIR_NO_DIALOGS:-0}" != "1" ]; then
        osascript -e "display dialog \"WSO2 project TLS repair failed\" & return & return & \"${message}\" buttons {\"OK\"} default button \"OK\" with icon stop giving up after 30" 2>/dev/null || true
    fi
    read -r -p "Press Return to close..." _ || true
    exit 1
}

echo "WSO2 Ballerina project TLS repair"
echo "================================="
echo

if [ "$(uname -m)" != "x86_64" ]; then
    show_message "No project TLS repair is needed. The Apple Silicon WSO2 package contains the correct native library."
    exit 0
fi

if [ ! -x "$BAL" ]; then
    show_error "Install WSO2 Integrator 5.0.0.1 in the Applications folder first."
fi

if [ ! -f "$ASSET" ]; then
    show_error "The verified native-library asset is missing. Extract and run the complete repair kit."
fi

ACTUAL_SHA1="$(shasum -a 1 "$ASSET" | awk '{print $1}')"
if [ "$ACTUAL_SHA1" != "$EXPECTED_SHA1" ]; then
    show_error "The native-library checksum does not match the verified Maven Central artifact."
fi

if ! unzip -l "$ASSET" | grep 'META-INF/native/libnetty_tcnative_osx_x86_64.jnilib' >/dev/null; then
    show_error "The native-library asset does not contain the required macOS Intel binary."
fi

PROJECT_DIR="${1:-}"
if [ -z "$PROJECT_DIR" ]; then
    DEFAULT_DIR="$HOME"
    if [ -d "$HOME/WSO2Integrator" ]; then
        DEFAULT_DIR="$HOME/WSO2Integrator"
    fi

    PROJECT_DIR="$(osascript - "$DEFAULT_DIR" <<'APPLESCRIPT' || true
on run argv
    set defaultFolder to POSIX file (item 1 of argv)
    set selectedFolder to choose folder with prompt "Select the Ballerina project folder containing Ballerina.toml" default location defaultFolder
    return POSIX path of selectedFolder
end run
APPLESCRIPT
)"

    if [ -z "$PROJECT_DIR" ]; then
        echo "No project selected. Nothing was changed."
        exit 0
    fi
fi

PROJECT_DIR="${PROJECT_DIR%/}"
MANIFEST="$PROJECT_DIR/Ballerina.toml"

if [ ! -f "$MANIFEST" ]; then
    CANDIDATES="$WORK_DIR/candidates.txt"
    find "$PROJECT_DIR" -maxdepth 3 -type f -name Ballerina.toml -print > "$CANDIDATES"
    CANDIDATE_COUNT="$(wc -l < "$CANDIDATES" | tr -d ' ')"
    if [ "$CANDIDATE_COUNT" = "1" ]; then
        MANIFEST="$(head -1 "$CANDIDATES")"
        PROJECT_DIR="$(dirname "$MANIFEST")"
    elif [ "$CANDIDATE_COUNT" = "0" ]; then
        show_error "The selected folder does not contain a Ballerina.toml project file."
    else
        show_error "The selected folder contains multiple projects. Run the repair again and select one specific project folder."
    fi
fi

echo "Selected project: $PROJECT_DIR"

PROJECT_LIBS="$PROJECT_DIR/libs"
PROJECT_JAR="$PROJECT_LIBS/$JAR_NAME"
MANIFEST_BACKUP="$MANIFEST.before-wso2-tls-repair"
cp -p "$MANIFEST" "$WORK_DIR/Ballerina.toml.original"

if [ ! -f "$MANIFEST_BACKUP" ]; then
    cp -p "$MANIFEST" "$MANIFEST_BACKUP"
fi

mkdir -p "$PROJECT_LIBS"
cp -p "$ASSET" "$PROJECT_JAR"

if ! grep -Fq "$JAR_NAME" "$MANIFEST"; then
    {
        echo
        echo "# WSO2 Integrator 5.0.0.1 Intel macOS TLS compatibility repair."
        echo "# The stock Netty classifier JAR has an empty native-library folder."
        echo "[[platform.java21.dependency]]"
        echo "path = \"libs/$JAR_NAME\""
    } >> "$MANIFEST"
fi

echo "Building the project to validate the repair..."
if ! (cd "$PROJECT_DIR" && "$BAL" build); then
    show_message "The TLS repair was installed, but this project currently has a separate compilation error. Fix the reported code error, then build again."
    exit 0
fi

EXECUTABLE_JAR="$(find "$PROJECT_DIR/target/bin" -maxdepth 1 -type f -name '*.jar' -print 2>/dev/null | head -1)"
if [ -z "$EXECUTABLE_JAR" ] ||
   ! unzip -l "$EXECUTABLE_JAR" | grep 'META-INF/native/libnetty_tcnative_osx_x86_64.jnilib' >/dev/null; then
    cp -p "$WORK_DIR/Ballerina.toml.original" "$MANIFEST"
    show_error "Validation failed, so Ballerina.toml was rolled back. The copied library remains in the project's libs folder but is inactive."
fi

show_message "WSO2 project TLS repair completed successfully. The project executable now contains the required macOS Intel native library."
