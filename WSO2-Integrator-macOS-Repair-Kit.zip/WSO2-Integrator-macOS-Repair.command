#!/bin/bash

set -euo pipefail

APP="/Applications/WSO2 Integrator.app"
CLI="$APP/Contents/Resources/app/bin/code"
EXTENSION_VERSION="5.12.3"
MARKETPLACE_URL="https://marketplace.visualstudio.com/_apis/public/gallery/publishers/WSO2/vsextensions/ballerina/${EXTENSION_VERSION}/vspackage"
USER_EXTENSION="$HOME/.wso2-integrator/extensions/wso2.ballerina-${EXTENSION_VERSION}"
EXTENSION_JS="$USER_EXTENSION/dist/extension.js"
PROFILE="$HOME/Library/Application Support/WSO2 Integrator"

show_error() {
    if [ "${WSO2_REPAIR_NO_DIALOGS:-0}" != "1" ]; then
        osascript -e "display dialog \"WSO2 Integrator repair failed\" & return & return & \"$1\" buttons {\"OK\"} default button \"OK\" with icon stop giving up after 30" 2>/dev/null || true
    fi
    echo
    echo "ERROR: $1"
    echo
    read -r -p "Press Return to close..."
    exit 1
}

if [ ! -d "$APP" ] || [ ! -x "$CLI" ]; then
    show_error "Install WSO2 Integrator in the Applications folder first."
fi

CPU_ARCH="$(uname -m)"
case "$CPU_ARCH" in
    x86_64|arm64) ;;
    *) show_error "Unsupported Mac architecture: $CPU_ARCH" ;;
esac

WORK_DIR="$(mktemp -d "${TMPDIR:-/tmp}/wso2-repair.XXXXXX")"
VSIX="$WORK_DIR/wso2-ballerina-${EXTENSION_VERSION}.vsix"

cleanup() {
    if [ -d "$WORK_DIR" ]; then
        find "$WORK_DIR" -depth -delete 2>/dev/null || true
    fi
}
trap cleanup EXIT

echo "WSO2 Integrator macOS repair"
echo "============================"
echo
echo "Mac architecture: $CPU_ARCH"
echo "Downloading the official WSO2 Ballerina extension ${EXTENSION_VERSION}..."

if ! curl --compressed -fL --retry 3 --connect-timeout 20 \
    -o "$VSIX" "$MARKETPLACE_URL"; then
    show_error "Could not download the official WSO2 extension. Check the internet connection and try again."
fi

if ! unzip -tq "$VSIX" >/dev/null 2>&1; then
    show_error "The downloaded extension is not a valid VSIX package."
fi

PACKAGE_VERSION="$(unzip -p "$VSIX" extension/package.json |
    plutil -extract version raw -o - - 2>/dev/null || true)"

if [ "$PACKAGE_VERSION" != "$EXTENSION_VERSION" ]; then
    show_error "Expected extension ${EXTENSION_VERSION}, but the download contains ${PACKAGE_VERSION:-an unknown version}."
fi

echo "Stopping WSO2 Integrator..."
osascript -e 'tell application "WSO2 Integrator" to quit' 2>/dev/null || true

attempt=0
while pgrep -f '/Applications/WSO2 Integrator.app' >/dev/null 2>&1 && [ "$attempt" -lt 8 ]; do
    sleep 1
    attempt=$((attempt + 1))
done

pkill -TERM -f '/Applications/WSO2 Integrator.app' 2>/dev/null || true
sleep 1

echo "Installing extension ${EXTENSION_VERSION}..."
"$CLI" --install-extension "$VSIX" --force

if [ ! -f "$EXTENSION_JS" ]; then
    show_error "The extension installed, but its main file was not found."
fi

BACKUP="$EXTENSION_JS.average-joe-original"
if [ ! -f "$BACKUP" ]; then
    cp -p "$EXTENSION_JS" "$BACKUP"
fi

echo "Applying desktop compatibility fixes..."

# WSO2's desktop visualizer incorrectly invokes a cloud-editor-only command.
perl -0pi -e \
    's/const t=void 0!==c\.commands\.executeCommand\("getContext","devant\.editor"\)/const t=!1/g' \
    "$EXTENSION_JS"

# The VSIX packages the WSO2 font under resources, but the generated code
# incorrectly requests it from node_modules.
perl -0pi -e \
    's/"node_modules","\@wso2","font-wso2-vscode","dist"/"resources","font-wso2-vscode","dist"/g' \
    "$EXTENSION_JS"

# The standalone product does not register this optional project-tree
# notification command. Make the startup notification a no-op.
perl -0pi -e \
    's/function N\(e,t,n,r\)\{try\{const i=h\.extensions\.getExtension\("wso2\.wso2-integrator"\);if\(i&&!i\.isActive\)return;h\.commands\.executeCommand\(u\.BI_COMMANDS\.NOTIFY_PROJECT_EXPLORER,\{projectPath:e,documentUri:t,position:n,view:r\}\)\}catch\(e\)\{console\.error\("Error notifying tree view:",e\)\}\}/function N(e,t,n,r){}/g' \
    "$EXTENSION_JS"

# WSO2 references this optional legacy stylesheet but does not package it.
mkdir -p "$USER_EXTENSION/resources/jslibs/themes"
touch "$USER_EXTENSION/resources/jslibs/themes/ballerina-default.min.css"

BAD_CONTEXT_COUNT="$(grep -F -o 'executeCommand("getContext","devant.editor")' "$EXTENSION_JS" 2>/dev/null | wc -l | tr -d ' ' || true)"
LOCAL_MODE_COUNT="$(grep -F -o 'getWebviewContent(e){const t=!1' "$EXTENSION_JS" 2>/dev/null | wc -l | tr -d ' ' || true)"
FIXED_FONT_COUNT="$(grep -F -o '"resources","font-wso2-vscode","dist"' "$EXTENSION_JS" 2>/dev/null | wc -l | tr -d ' ' || true)"
NOTIFY_FIX_COUNT="$(grep -F -o 'function N(e,t,n,r){}' "$EXTENSION_JS" 2>/dev/null | wc -l | tr -d ' ' || true)"

if [ "$BAD_CONTEXT_COUNT" != "0" ] ||
   [ "$LOCAL_MODE_COUNT" != "1" ] ||
   [ "$FIXED_FONT_COUNT" != "1" ] ||
   [ "$NOTIFY_FIX_COUNT" != "1" ]; then
    cp -p "$BACKUP" "$EXTENSION_JS"
    show_error "The WSO2 extension layout has changed, so this repair was stopped and rolled back safely."
fi

echo "Clearing disposable webview caches..."
for CACHE_NAME in "GPUCache" "Cache" "Service Worker" "Code Cache"; do
    CACHE_PATH="$PROFILE/$CACHE_NAME"
    if [ -d "$CACHE_PATH" ]; then
        find "$CACHE_PATH" -depth -delete 2>/dev/null || true
    fi
done

echo "Preventing an automatic extension update from undoing the repair..."
SETTINGS_FILE="$PROFILE/User/settings.json"
mkdir -p "$PROFILE/User"
SETTINGS_PATH="$SETTINGS_FILE" ELECTRON_RUN_AS_NODE=1 "$APP/Contents/MacOS/Electron" -e '
const fs = require("fs");
const settingsPath = process.env.SETTINGS_PATH;
let settings = {};
try {
    settings = JSON.parse(fs.readFileSync(settingsPath, "utf8"));
} catch (_) {}
settings["extensions.autoCheckUpdates"] = false;
settings["extensions.autoUpdate"] = false;
fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 4) + "\n");
'

echo "Restarting WSO2 Integrator..."
open -a "$APP"

echo
echo "Repair completed successfully."
echo "Installed extension: wso2.ballerina@${EXTENSION_VERSION}"
echo

if [ "${WSO2_REPAIR_NO_DIALOGS:-0}" != "1" ]; then
    osascript -e 'display dialog "WSO2 Integrator repair completed successfully." & return & return & "Open your project and select HTTP Service again." buttons {"OK"} default button "OK" with icon note giving up after 30' 2>/dev/null || true
fi
